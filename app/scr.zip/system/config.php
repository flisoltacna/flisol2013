<?php
######### edit details ##########
$appId              = '558960440803126'; //Facebook App ID
$appSecret          = 'f3db9eb9c1a3d2a6f4590281f42e19c0'; // Facebook App Secret
$return_url         = 'http://www.ikeyserver.tk/nuevo/system/login.php';  //return url (url to script)
$temp_folder        = 'tmp/'; //temp dir path to store images
$fbPermissions      = 'publish_stream,user_hometown,user_birthday';  //Required facebook permissions
$image_id_png       = 'assets/card_perfilNew.png'; // id card image template path
$font               = 'assets/fonts/DidactGothic.ttf'; //font used
#################################

?>
 <a href="http://www.flisoltacna2013.info/" id="logo">
                	<img src="static/images/logo_flisol.png" id="logo" alt="FLISOL Tacna" />
                </a>
                
<h1>FLISOL Tacna</h1>
<p>Crea tus tarjetas de FLISOL Tacna!</p>
                
<div class="button" align="center">
<a href="#login" onclick="fbloginOpen(); return false;" class="medium facebook" ><img src="static/images/fb.png" alt="Facebook logo" />Ingresar ahora!</a>
                	</div><br />
                    
<div class="fb-like" data-href="http://www.flisoltacna2013.info" data-send="false" data-layout="box_count" data-width="450" data-show-faces="false"></div>

<?php
	define('BD_HOST', 'localhost');
	define('BD_USUARIO', 'root');
	define('BD_PASSWORD', '');
	define('BD_NOMBRE', 'bd_flisol');
	define('URL_APP', 'http://localhost/flisol2013/');
?>
<?php function footer(){?>
	<div class="container">
		<footer>
			<p>&copy; Company 2012</p>
		</footer>
	</div>
	
</body>
</html>
<?php };?>